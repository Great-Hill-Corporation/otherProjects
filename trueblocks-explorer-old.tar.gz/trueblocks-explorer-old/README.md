# trueblocks-explorer

```
git clone https://github.com/tjayrush/trueblocks-explorer.git
cd trueblocks-explorer
yarn install
yarn start
```
